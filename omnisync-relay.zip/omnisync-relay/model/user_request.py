from pydantic import BaseModel
from typing import Optional

from pydantic import BaseModel


class UserCreate(BaseModel):
    # Identity IDs
    slack_user_id: str  # The unique ID from Slack (e.g., U12345)
    slack_channel_id: str  # Where the bot sends the 5:00 PM summary

    # Human Details
    full_name: str  # Real name for the Gemini summary (e.g., "John Doe")

    # Tool Handles
    gitlab_username: str  # Used to match GitLab webhooks to this user
    jira_username: str  # Used to match Jira ticket updates to this user

    # Timing Logic
    timezone: str = "UTC"  # Used to calculate the 5:00 PM local handoff
    handoff_time: str = "17:00"