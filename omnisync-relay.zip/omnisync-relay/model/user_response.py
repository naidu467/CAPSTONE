from pydantic import BaseModel
from typing import List, Optional

from typing import Optional

from model.user_request import UserCreate


class UserResponse(UserCreate):
    id: Optional[int] = None      # Changed to Optional
    is_active: Optional[bool] = True # Provide a default