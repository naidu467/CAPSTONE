"""
main.py — OmniSync Relay: FastAPI application entry point.

Endpoints
---------
POST /webhook            Ingest a raw GitLab/Jira webhook → SQLite Waiting Room
POST /callback/approve   Handle "Approve & Sync" card click  → ChromaDB + mark processed
POST /callback/dismiss   Handle "Dismiss" card click         → leave events pending
POST /trigger/handoff    Dev shortcut: run the 5 PM handoff now
POST /trigger/standup    Dev shortcut: run the 9 AM standup now
GET  /health             Liveness probe

Scheduled jobs (APScheduler, UTC)
----------------------------------
17:00  run_evening_handoff() — summarise & send approval cards
09:00  run_morning_standup() — synthesise & post Global Standup
"""

import logging
from contextlib import asynccontextmanager
from typing import Any

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from fastapi import FastAPI, HTTPException, Request, status
from fastapi.responses import JSONResponse

import ai_engine as ai
import database_mgr as db
import user_registration
from chat_adapter import ChatMessage, default_adapter

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler(timezone="UTC")


# ---------------------------------------------------------------------------
# Core workflow functions
# ---------------------------------------------------------------------------

async def run_evening_handoff() -> None:
    """
    5 PM Handoff: for every user with pending events, ask Gemini to
    generate a 3-bullet summary and send a Google Chat approval card.
    Raw events stay in SQLite until the user clicks "Approve & Sync".
    """
    logger.info("=== 5 PM Evening Handoff started ===")
    user_ids = db.get_all_users_with_pending()

    if not user_ids:
        logger.info("No pending events found. Handoff skipped.")
        return

    for user_id in user_ids:
        events = db.get_pending_events_by_user(user_id)
        event_ids = [e["id"] for e in events]
        events_for_ai = [
            {"tool_source": e["tool_source"], "raw_payload": e["raw_payload"]}
            for e in events
        ]

        summary = ai.generate_summary(user_id, events_for_ai)
        if not summary:
            logger.warning("Skipping approval card for %s: summary failed", user_id)
            continue

        card = default_adapter.build_approval_card(user_id, summary, event_ids)
        msg = ChatMessage(text=f"Daily summary ready for {user_id}", card=card)
        default_adapter.send_message(msg, user_id=user_id)
        logger.info(
            "Approval card sent for user=%s covering %d event(s)", user_id, len(event_ids)
        )


async def run_morning_standup() -> None:
    """
    9 AM Brief: pull all approved summaries from the last 24 h out of
    ChromaDB, ask Gemini to synthesise a Global Standup, and post it
    to the team space.
    """
    logger.info("=== 9 AM Morning Standup started ===")
    summaries = ai.query_last_24h_summaries()
    report = ai.synthesize_standup(summaries)

    if not report:
        logger.warning("Standup synthesis returned empty; skipping post.")
        return

    card = default_adapter.build_standup_card(report)
    msg = ChatMessage(text="Good morning! Here is today's Global Standup.", card=card)
    default_adapter.send_message(msg)
    logger.info("Morning standup posted to team space.")


# ---------------------------------------------------------------------------
# App lifecycle
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init_db()
    scheduler.add_job(run_evening_handoff, CronTrigger(hour=17, minute=0), id="handoff")
    scheduler.add_job(run_morning_standup, CronTrigger(hour=9,  minute=0), id="standup")
    scheduler.start()
    logger.info("OmniSync Relay is running. Scheduler armed (UTC).")
    yield
    scheduler.shutdown()
    logger.info("OmniSync Relay shut down.")


app = FastAPI(
    title="OmniSync Relay",
    description=(
        "Human-in-the-loop developer activity aggregator. "
        "Raw webhooks → SQLite → Gemini summary → human approval → ChromaDB."
    ),
    version="1.0.0",
    lifespan=lifespan,
)

app.include_router(user_registration.router)


# ---------------------------------------------------------------------------
# Ingestion endpoint
# ---------------------------------------------------------------------------

@app.post("/webhook", status_code=status.HTTP_202_ACCEPTED)
async def ingest_webhook(request: Request) -> dict:
    """
    Receive a raw GitLab or Jira webhook and park it in the SQLite Waiting Room.

    Required headers
    ----------------
    X-User-Id    : developer identifier (e.g. "alice")
    X-Tool-Source: event origin        (e.g. "gitlab" | "jira")
    """
    user_id = request.headers.get("X-User-Id")
    tool_source = request.headers.get("X-Tool-Source", "unknown")

    if not user_id:
        raise HTTPException(status_code=400, detail="Missing required header: X-User-Id")

    try:
        payload: Any = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Request body must be valid JSON")

    event_id = db.insert_event(user_id, tool_source, payload)
    return {"status": "accepted", "event_id": event_id}


# ---------------------------------------------------------------------------
# Approval callback endpoints
# ---------------------------------------------------------------------------

@app.post("/callback/approve")
async def approve_and_sync(request: Request) -> JSONResponse:
    """
    Google Chat Card callback for the "Approve & Sync" button.

    Workflow
    --------
    1. Extract user_id, summary, and event_ids from the card action parameters.
    2. Generate a text-embedding-004 vector for the approved summary.
    3. Write the embedding + summary to ChromaDB (Collective Brain).
    4. Mark the originating SQLite rows as processed.

    Raw webhook data never touches ChromaDB — only the Gemini-generated,
    human-approved summary does.
    """
    body = await request.json()
    params = _extract_card_params(body)

    user_id: str = params.get("user_id", "")
    summary: str = params.get("summary", "")
    event_ids_raw: str = params.get("event_ids", "")

    if not user_id or not summary:
        raise HTTPException(
            status_code=400, detail="Callback payload missing user_id or summary"
        )

    event_ids = [int(i) for i in event_ids_raw.split(",") if i.strip().isdigit()]

    try:
        doc_id = ai.store_summary_in_chromadb(user_id, summary, event_ids)
    except RuntimeError as exc:
        logger.error("ChromaDB write aborted: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to store summary in Collective Brain")

    if event_ids:
        db.mark_events_processed(event_ids)

    logger.info(
        "Approval complete: user=%s doc_id=%s events_closed=%d",
        user_id, doc_id, len(event_ids),
    )
    # Google Chat replaces the card message with this text acknowledgement.
    return JSONResponse(
        {
            "actionResponse": {"type": "UPDATE_MESSAGE"},
            "text": (
                f"Summary approved and synced to the Collective Brain "
                f"(doc: {doc_id[:8]}…). {len(event_ids)} event(s) marked processed."
            ),
        }
    )


@app.post("/callback/dismiss")
async def dismiss_summary(request: Request) -> JSONResponse:
    """
    Google Chat Card callback for the "Dismiss" button.
    Events remain 'pending' in SQLite and will be included in the next handoff.
    """
    body = await request.json()
    params = _extract_card_params(body)
    user_id = params.get("user_id", "unknown")
    logger.info("Summary dismissed by user=%s. Events remain pending.", user_id)

    return JSONResponse(
        {
            "actionResponse": {"type": "UPDATE_MESSAGE"},
            "text": (
                "Summary dismissed. Your events will roll over into tomorrow's handoff."
            ),
        }
    )


# ---------------------------------------------------------------------------
# Manual trigger endpoints (development / testing)
# ---------------------------------------------------------------------------

@app.post("/trigger/handoff", status_code=status.HTTP_202_ACCEPTED)
async def manual_handoff() -> dict:
    """Immediately run the 5 PM Evening Handoff (useful for local testing)."""
    await run_evening_handoff()
    return {"status": "handoff triggered"}


@app.post("/trigger/standup", status_code=status.HTTP_202_ACCEPTED)
async def manual_standup() -> dict:
    """Immediately run the 9 AM Morning Standup (useful for local testing)."""
    await run_morning_standup()
    return {"status": "standup triggered"}


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@app.get("/health")
async def health() -> dict:
    return {"status": "ok", "service": "OmniSync Relay"}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_card_params(body: dict) -> dict:
    """
    Pull action parameters from a Google Chat Card interaction body.

    Google Chat v2 sends: body["action"]["parameters"] as [{key, value}, ...]
    Falls back to reading the body directly to simplify curl-based local tests.
    """
    try:
        raw = body["action"]["parameters"]
        return {p["key"]: p["value"] for p in raw}
    except (KeyError, TypeError):
        return body
