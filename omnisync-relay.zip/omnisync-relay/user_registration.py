import sqlite3
from typing import List

from fastapi import APIRouter, HTTPException

from model.user_request import UserCreate
from model.user_response import UserResponse

router = APIRouter()
DB_PATH = "users.db"


@router.post("/users/register")
async def register_user(user: UserCreate):
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        # Insert or Replace to handle profile updates
        query = """
            INSERT INTO users (
                slack_user_id, slack_channel_id, full_name, 
                gitlab_username, jira_username, timezone, handoff_time
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        """

        cursor.execute(query, (
            user.slack_user_id,
            user.slack_channel_id,
            user.full_name,
            user.gitlab_username,
            user.jira_username,
            user.timezone,
            user.handoff_time
        ))

        conn.commit()
        conn.close()

        return {"status": "success", "message": f"User {user.full_name} registered successfully."}

    except sqlite3.IntegrityError:
        raise HTTPException(status_code=400, detail="User already exists or ID conflict.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/users", response_model=List[UserResponse])
async def get_all_users():
    """Returns all registered users for the 5:00 PM Handoff Cron job."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users")
    rows = cursor.fetchall()
    conn.close()

    # THE FIX: Convert each sqlite3.Row object into a standard Python dictionary
    return [dict(row) for row in rows]


@router.get("/users/{slack_id}", response_model=UserResponse)
async def get_user_by_slack_id(slack_id: str):
    """Retrieves a single user's profile using their Slack ID."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM users WHERE slack_user_id = ?", (slack_id,))
    user_row = cursor.fetchone()
    conn.close()

    if user_row is None:
        raise HTTPException(status_code=404, detail="User not found in OmniSync records.")

    # THE FIX: Convert the single row object to a dictionary
    return dict(user_row)