"""
chat_adapter.py — Adapter Pattern for Google Chat.

The core modules (ai_engine, database_mgr, main) stay platform-agnostic by
working with ChatMessage objects. Only this file knows about the Google Chat
wire format, so swapping platforms means updating one file.
"""

import logging
import os
from dataclasses import dataclass, field
from typing import Dict, Optional

import httpx
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Platform-agnostic message contract
# ---------------------------------------------------------------------------

@dataclass
class ChatMessage:
    """Thin carrier that both adapters and callers agree on."""
    text: str
    card: Optional[dict] = field(default=None)


# ---------------------------------------------------------------------------
# Abstract base (keeps callers honest)
# ---------------------------------------------------------------------------

class BaseChatAdapter:
    def send_message(self, message: ChatMessage) -> bool:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Google Chat implementation
# ---------------------------------------------------------------------------

class GoogleChatAdapter(BaseChatAdapter):
    """
    Translates ChatMessage objects into Google Chat API payloads and
    delivers them to an incoming-webhook URL.

    Per-user webhook URLs can be provided to route approval cards directly
    to individual DM spaces. Falls back to the team webhook if not found.
    """

    def __init__(
        self,
        team_webhook_url: str,
        service_base_url: str = "http://localhost:8000",
        user_webhooks: Optional[Dict[str, str]] = None,
    ) -> None:
        self.team_webhook_url = team_webhook_url
        self.service_base_url = service_base_url
        self.user_webhooks: Dict[str, str] = user_webhooks or {}

    # ------------------------------------------------------------------
    # Delivery
    # ------------------------------------------------------------------

    def send_message(self, message: ChatMessage, user_id: Optional[str] = None) -> bool:
        """
        Post *message* to Google Chat.
        If *user_id* is given and a per-user webhook is registered, that
        webhook is used; otherwise the team webhook is used.
        """
        url = self.user_webhooks.get(user_id or "", self.team_webhook_url)
        payload = {"cardsV2": [message.card]} if message.card else {"text": message.text}
        try:
            response = httpx.post(url, json=payload, timeout=10)
            response.raise_for_status()
            logger.info("Google Chat delivery OK (status=%d)", response.status_code)
            return True
        except httpx.HTTPError as exc:
            logger.error("Google Chat delivery failed: %s", exc)
            return False

    # ------------------------------------------------------------------
    # Card builders
    # ------------------------------------------------------------------

    def build_approval_card(
        self, user_id: str, summary: str, event_ids: list
    ) -> dict:
        """
        Google Chat Cards v2 payload with a 3-bullet summary and two
        action buttons: "Approve & Sync" and "Dismiss".

        The button onClick actions POST back to our /callback/* endpoints,
        carrying user_id, summary, and event_ids as card parameters.
        """
        event_ids_str = ",".join(str(i) for i in event_ids)
        approve_url = f"{self.service_base_url}/callback/approve"
        dismiss_url = f"{self.service_base_url}/callback/dismiss"

        return {
            "cardId": f"approval-{user_id}",
            "card": {
                "header": {
                    "title": "OmniSync Daily Summary",
                    "subtitle": f"Developer: {user_id}",
                    "imageUrl": (
                        "https://fonts.gstatic.com/s/i/"
                        "googlematerialicons/sync/v6/24px.svg"
                    ),
                    "imageType": "CIRCLE",
                },
                "sections": [
                    {
                        "header": "Today's Activity",
                        "widgets": [
                            {
                                "textParagraph": {
                                    "text": summary.replace("\n", "<br>")
                                }
                            }
                        ],
                    },
                    {
                        "widgets": [
                            {
                                "buttonList": {
                                    "buttons": [
                                        {
                                            "text": "Approve & Sync to Collective Brain",
                                            "onClick": {
                                                "action": {
                                                    "function": approve_url,
                                                    "parameters": [
                                                        {"key": "user_id",   "value": user_id},
                                                        {"key": "summary",   "value": summary},
                                                        {"key": "event_ids", "value": event_ids_str},
                                                    ],
                                                }
                                            },
                                            "color": {
                                                "red": 0.0, "green": 0.6,
                                                "blue": 0.4, "alpha": 1.0,
                                            },
                                        },
                                        {
                                            "text": "Dismiss",
                                            "onClick": {
                                                "action": {
                                                    "function": dismiss_url,
                                                    "parameters": [
                                                        {"key": "user_id",   "value": user_id},
                                                        {"key": "event_ids", "value": event_ids_str},
                                                    ],
                                                }
                                            },
                                        },
                                    ]
                                }
                            }
                        ],
                    },
                ],
            },
        }

    def build_standup_card(self, report: str) -> dict:
        """Google Chat Cards v2 payload for the morning Global Standup report."""
        return {
            "cardId": "morning-standup",
            "card": {
                "header": {
                    "title": "OmniSync Global Standup",
                    "subtitle": "Synthesised from yesterday's approved summaries",
                    "imageUrl": (
                        "https://fonts.gstatic.com/s/i/"
                        "googlematerialicons/groups/v7/24px.svg"
                    ),
                    "imageType": "CIRCLE",
                },
                "sections": [
                    {
                        "widgets": [
                            {
                                "textParagraph": {
                                    "text": report.replace("\n", "<br>")
                                }
                            }
                        ]
                    }
                ],
            },
        }


# ---------------------------------------------------------------------------
# Module-level default adapter (configure via .env)
# ---------------------------------------------------------------------------

def _load_user_webhooks() -> Dict[str, str]:
    """
    Optional: set GOOGLE_CHAT_USER_WEBHOOKS as a JSON string in .env, e.g.:
    {"alice": "https://chat.googleapis.com/...", "bob": "https://..."}
    """
    import json
    raw = os.getenv("GOOGLE_CHAT_USER_WEBHOOKS", "{}")
    try:
        return json.loads(raw)
    except Exception:
        return {}


default_adapter = GoogleChatAdapter(
    team_webhook_url=os.getenv(
        "GOOGLE_CHAT_WEBHOOK_URL", "YOUR_GOOGLE_CHAT_TEAM_WEBHOOK_URL"
    ),
    service_base_url=os.getenv("SERVICE_BASE_URL", "http://localhost:8000"),
    user_webhooks=_load_user_webhooks(),
)
