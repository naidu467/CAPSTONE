"""
ai_engine.py — AI Engine: Gemini 1.5 Flash for text generation,
text-embedding-004 for vectors, ChromaDB as the Collective Brain.

RULE: store_summary_in_chromadb() is the ONLY write path to ChromaDB.
It must only be called after human approval — never from the ingestion path.
"""

import logging
import os
import uuid
from datetime import datetime, timedelta
from typing import List, Optional

import chromadb
#import google.generativeai as genai
from google import genai
from google.genai import types
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
# DUSHYANTH: AIzaSyB4aKaLowZ9O8RXN0WRarnDhpnzSqxppXQ
# BASAVA: AIzaSyCblQweaRIeu4W8KaqVOZfDjDELm5ZBj6Q
GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "AIzaSyB4aKaLowZ9O8RXN0WRarnDhpnzSqxppXQ")
CHROMA_PERSIST_DIR: str = os.getenv("CHROMA_PERSIST_DIR", "./chroma_store")
CHROMA_COLLECTION: str = "collective_brain"

# genai.configure(api_key=GEMINI_API_KEY)
# _flash = genai.GenerativeModel("gemini-1.5-flash")
client = genai.Client(api_key=GEMINI_API_KEY, http_options=types.HttpOptions(api_version='v1'))
MODEL_NAME = "gemini-1.5-flash"

_chroma = chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)
_collection = _chroma.get_or_create_collection(
    name=CHROMA_COLLECTION,
    metadata={"hnsw:space": "cosine"},
)


# ---------------------------------------------------------------------------
# Summary generation
# ---------------------------------------------------------------------------

def generate_summary(user_id: str, events: List[dict]) -> Optional[str]:
    """
    Ask Gemini 1.5 Flash to condense a user's daily activity into exactly
    3 bullet points. Returns None if the call fails.
    """
    if not events:
        return None

    activity_block = "\n".join(
        f"[{e['tool_source']}] {e['raw_payload']}" for e in events
    )
    prompt = (
        f"You are a developer productivity assistant.\n"
        f"Below is today's raw activity log for developer '{user_id}'.\n\n"
        f"{activity_block}\n\n"
        f"Summarise this activity in exactly 3 concise bullet points.\n"
        f"Focus on: completed work, current blockers, and immediate next steps.\n"
        f"Be specific. Avoid filler phrases."
    )

    try:
        response = client.models.generate_content(model=MODEL_NAME, contents=prompt)
        summary = response.text.strip()
        logger.info("Summary generated for %s (%d chars)", user_id, len(summary))
        return summary
    except Exception as exc:
        logger.error("Gemini summary failed for %s: %s", user_id, exc)
        return None


# ---------------------------------------------------------------------------
# Embedding generation
# ---------------------------------------------------------------------------

def generate_embedding(text: str) -> Optional[List[float]]:
    """Return a text-embedding-004 vector, or None on failure."""
    try:
        result = client.models.embed_content(
            model="text-embedding-004",
            contents=text,
            config=types.EmbedContentConfig(task_type="RETRIEVAL_DOCUMENT"),
        )
        return result.embeddings[0].values
    except Exception as exc:
        logger.error("Embedding generation failed: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Collective Brain (ChromaDB) writes — approved summaries only
# ---------------------------------------------------------------------------

def store_summary_in_chromadb(
    user_id: str,
    summary: str,
    event_ids: List[int],
) -> str:
    """
    Embed an *approved* summary and write it to the Collective Brain.

    This is intentionally the sole write path to ChromaDB.
    Calling this with raw, unapproved data violates the Human-in-the-Loop rule.

    Returns the ChromaDB document ID.
    Raises RuntimeError if embedding generation fails.
    """
    embedding = generate_embedding(summary)
    if embedding is None:
        raise RuntimeError(
            "Embedding generation failed — refusing to write to Collective Brain."
        )

    doc_id = str(uuid.uuid4())
    approved_at_ts = int(datetime.utcnow().timestamp())

    _collection.add(
        ids=[doc_id],
        embeddings=[embedding],
        documents=[summary],
        metadatas=[
            {
                "user_id": user_id,
                "approved_at": datetime.utcnow().isoformat(),
                "approved_at_ts": approved_at_ts,   # int, used for range queries
                "source_event_ids": ",".join(str(i) for i in event_ids),
            }
        ],
    )
    logger.info(
        "Stored approved summary in ChromaDB: doc_id=%s user=%s events=%s",
        doc_id,
        user_id,
        event_ids,
    )
    return doc_id


# ---------------------------------------------------------------------------
# Collective Brain reads
# ---------------------------------------------------------------------------

def query_last_24h_summaries() -> List[str]:
    """
    Retrieve all approved summaries added to ChromaDB in the last 24 hours.
    Uses the integer approved_at_ts metadata field for reliable range filtering.
    """
    cutoff_ts = int((datetime.utcnow() - timedelta(hours=24)).timestamp())
    try:
        results = _collection.get(
            where={"approved_at_ts": {"$gt": cutoff_ts}},
        )
        docs: List[str] = results.get("documents") or []
    except Exception as exc:
        # Collection may be empty; treat as zero results rather than crashing.
        logger.warning("ChromaDB get() failed (empty collection?): %s", exc)
        docs = []

    logger.info("Retrieved %d approved summary/summaries from the last 24 h", len(docs))
    return docs


def synthesize_standup(summaries: List[str]) -> Optional[str]:
    """
    Ask Gemini 1.5 Flash to produce a structured Global Standup report
    from all team members' approved summaries.
    """
    if not summaries:
        return "No activity summaries were approved in the last 24 hours."

    combined = "\n\n---\n\n".join(summaries)
    prompt = (
        "You are a senior engineering lead preparing the morning standup report.\n"
        "Below are approved daily summaries from individual team members.\n\n"
        f"{combined}\n\n"
        "Synthesise a concise 'Global Standup' report with these three sections:\n"
        "1. **Completed Yesterday** — key achievements across the team\n"
        "2. **In Progress Today** — active workstreams and owners\n"
        "3. **Blockers & Risks** — items needing immediate attention\n\n"
        "Stay under 300 words. Use bullet points."
    )

    try:
        response = client.models.generate_content(model=MODEL_NAME, contents=prompt)
        report = response.text.strip()
        logger.info("Standup report synthesised (%d chars)", len(report))
        return report
    except Exception as exc:
        logger.error("Standup synthesis failed: %s", exc)
        return None
