"""
database_mgr.py — SQLite "Waiting Room" for raw, pending webhook events.

Raw payloads live here until a human approves them. Nothing moves to
ChromaDB without going through the approval loop first.
"""

import json
import logging
import sqlite3
from contextlib import contextmanager
from datetime import datetime
from typing import List

logger = logging.getLogger(__name__)

DB_PATH = "omnisync.db"


@contextmanager
def _connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    """Create the event_logs and users tables and supporting indices if they don't exist."""
    with _connection() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS event_logs (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     TEXT    NOT NULL,
                tool_source TEXT    NOT NULL,
                raw_payload TEXT    NOT NULL,
                status      TEXT    NOT NULL DEFAULT 'pending'
                                    CHECK(status IN ('pending', 'processed')),
                timestamp   TEXT    NOT NULL
            )
        """)
        conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_user_status "
            "ON event_logs(user_id, status)"
        )
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                slack_user_id     TEXT PRIMARY KEY,
                slack_channel_id  TEXT,
                full_name         TEXT,
                gitlab_username   TEXT,
                jira_username     TEXT,
                timezone          TEXT DEFAULT 'UTC',
                handoff_time      TEXT DEFAULT '17:00'
            )
        """)
    logger.info("SQLite Waiting Room initialised at %s", DB_PATH)


def insert_event(user_id: str, tool_source: str, raw_payload: dict) -> int:
    """Persist a raw webhook payload. Returns the new row id."""
    with _connection() as conn:
        cursor = conn.execute(
            "INSERT INTO event_logs (user_id, tool_source, raw_payload, timestamp) "
            "VALUES (?, ?, ?, ?)",
            (user_id, tool_source, json.dumps(raw_payload), datetime.utcnow().isoformat()),
        )
        event_id: int = cursor.lastrowid  # type: ignore[assignment]
    logger.info("Inserted event id=%d for user=%s source=%s", event_id, user_id, tool_source)
    return event_id


def get_pending_events_by_user(user_id: str) -> List[sqlite3.Row]:
    """Return all pending rows for *user_id*, ordered oldest-first."""
    with _connection() as conn:
        return conn.execute(
            "SELECT * FROM event_logs "
            "WHERE user_id = ? AND status = 'pending' "
            "ORDER BY timestamp ASC",
            (user_id,),
        ).fetchall()


def get_all_users_with_pending() -> List[str]:
    """Return the distinct user IDs that have at least one pending event."""
    with _connection() as conn:
        rows = conn.execute(
            "SELECT DISTINCT user_id FROM event_logs WHERE status = 'pending'"
        ).fetchall()
    return [row["user_id"] for row in rows]


def mark_events_processed(event_ids: List[int]) -> int:
    """Flip a batch of event rows from 'pending' to 'processed'. Returns row count."""
    if not event_ids:
        return 0
    placeholders = ",".join("?" * len(event_ids))
    with _connection() as conn:
        cursor = conn.execute(
            f"UPDATE event_logs SET status = 'processed' WHERE id IN ({placeholders})",
            event_ids,
        )
        count: int = cursor.rowcount
    logger.info("Marked %d event(s) as processed", count)
    return count
