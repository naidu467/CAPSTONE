"""
Real-Time Flight Data Collector using OpenSky Network API
Collects live flight data including position, altitude, velocity, etc.
"""

import time
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
import requests
import logging
import os
import sys
from pathlib import Path

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent.parent))

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/flight_collector.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class FlightCollector:
    """
    Collects real-time flight data from OpenSky Network API

    Features:
    - Real-time flight tracking
    - Regional filtering
    - Data validation and cleaning
    - Automatic retry on failures
    """

    BASE_URL = "https://opensky-network.org/api"

    def __init__(self, username: Optional[str] = None, password: Optional[str] = None):
        """
        Initialize Flight Collector

        Args:
            username: OpenSky username (optional, for higher rate limits)
            password: OpenSky password (optional)
        """
        self.username = username
        self.password = password
        self.session = requests.Session()

        # Rate limiting
        self.last_request_time = 0
        self.min_request_interval = 10  # seconds (OpenSky recommends 10s for anonymous)

        # Data storage
        self.flight_history = []

        # Create data directory
        os.makedirs('data/raw', exist_ok=True)

        logger.info("FlightCollector initialized")

    def get_states(self, bbox: Optional[Tuple[float, float, float, float]] = None) -> Optional[List[Dict]]:
        """
        Get current flight states from OpenSky Network

        Args:
            bbox: Bounding box (lat_min, lat_max, lon_min, lon_max)

        Returns:
            List of flight state dictionaries
        """
        # Rate limiting
        time_since_last = time.time() - self.last_request_time
        if time_since_last < self.min_request_interval:
            wait_time = self.min_request_interval - time_since_last
            logger.info(f"Rate limiting: waiting {wait_time:.1f}s")
            time.sleep(wait_time)

        # Build URL
        url = f"{self.BASE_URL}/states/all"
        params = {}

        if bbox:
            params = {
                'lamin': bbox[0],
                'lamax': bbox[1],
                'lomin': bbox[2],
                'lomax': bbox[3]
            }

        try:
            # Make request
            if self.username and self.password:
                response = self.session.get(
                    url,
                    params=params,
                    auth=(self.username, self.password),
                    timeout=30
                )
            else:
                response = self.session.get(url, params=params, timeout=30)

            self.last_request_time = time.time()

            if response.status_code == 200:
                data = response.json()
                states = self._parse_states(data)
                logger.info(f"Retrieved {len(states)} flight states")
                return states
            else:
                logger.error(f"API error: {response.status_code}")
                return None

        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {str(e)}")
            return None

    def _parse_states(self, data: Dict) -> List[Dict]:
        """
        Parse OpenSky API response into structured format

        Args:
            data: Raw API response

        Returns:
            List of parsed flight dictionaries
        """
        if not data or 'states' not in data:
            return []

        flights = []
        timestamp = data['time']

        for state in data['states']:
            try:
                flight = {
                    'timestamp': datetime.fromtimestamp(timestamp),
                    'icao24': state[0],  # Unique aircraft identifier
                    'callsign': state[1].strip() if state[1] else None,
                    'origin_country': state[2],
                    'time_position': state[3],
                    'last_contact': state[4],
                    'longitude': state[5],
                    'latitude': state[6],
                    'baro_altitude': state[7],  # meters
                    'on_ground': state[8],
                    'velocity': state[9],  # m/s
                    'true_track': state[10],  # degrees
                    'vertical_rate': state[11],  # m/s
                    'sensors': state[12],
                    'geo_altitude': state[13],  # meters
                    'squawk': state[14],
                    'spi': state[15],
                    'position_source': state[16]
                }

                # Only include flights with valid position data
                if flight['longitude'] and flight['latitude']:
                    flights.append(flight)

            except (IndexError, TypeError) as e:
                logger.warning(f"Error parsing state: {str(e)}")
                continue

        return flights

    def collect_flights_region(self, region_name: str, bbox: Tuple[float, float, float, float],
                               duration_minutes: int = 60, interval_seconds: int = 60):
        """
        Collect flight data for a specific region over time

        Args:
            region_name: Name of the region
            bbox: Bounding box coordinates
            duration_minutes: How long to collect data
            interval_seconds: Time between collections
        """
        logger.info(f"Starting data collection for {region_name}")
        logger.info(f"Duration: {duration_minutes} minutes, Interval: {interval_seconds}s")

        end_time = datetime.now() + timedelta(minutes=duration_minutes)
        collection_count = 0

        while datetime.now() < end_time:
            collection_count += 1
            logger.info(f"\n{'='*60}")
            logger.info(f"Collection #{collection_count} - {datetime.now()}")

            # Get current states
            states = self.get_states(bbox=bbox)

            if states:
                # Add to history
                self.flight_history.extend(states)

                # Display summary
                in_air = sum(1 for s in states if not s['on_ground'])
                on_ground = len(states) - in_air

                logger.info(f"Flights tracked: {len(states)} (In air: {in_air}, On ground: {on_ground})")

                # Save periodically
                if collection_count % 5 == 0:
                    self.save_data(region_name)

            # Wait for next interval
            if datetime.now() < end_time:
                logger.info(f"Waiting {interval_seconds}s until next collection...")
                time.sleep(interval_seconds)

        logger.info(f"\nCollection complete! Total records: {len(self.flight_history)}")
        self.save_data(region_name)

    def save_data(self, region_name: str):
        """
        Save collected flight data to CSV

        Args:
            region_name: Name of the region
        """
        if not self.flight_history:
            logger.warning("No data to save")
            return

        df = pd.DataFrame(self.flight_history)

        # Create filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"data/raw/flights_{region_name}_{timestamp}.csv"

        df.to_csv(filename, index=False)
        logger.info(f"Saved {len(df)} records to {filename}")

        # Also save as latest
        latest_filename = f"data/raw/flights_{region_name}_latest.csv"
        df.to_csv(latest_filename, index=False)
        logger.info(f"Saved as latest: {latest_filename}")

    def get_dataframe(self) -> pd.DataFrame:
        """
        Get collected data as DataFrame

        Returns:
            DataFrame with flight data
        """
        return pd.DataFrame(self.flight_history)

    def clear_history(self):
        """Clear collected flight history"""
        self.flight_history = []
        logger.info("Flight history cleared")


def main():
    """
    Main function to demonstrate flight data collection
    """
    import yaml

    # Load configuration
    config_path = 'config/config.yaml'
    if os.path.exists(config_path):
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
    else:
        logger.warning("Config file not found, using defaults")
        config = {
            'data_collection': {
                'regions': {
                    'usa_east': [30, 50, -90, -70]
                },
                'collection_interval': 60
            }
        }

    # Create collector
    collector = FlightCollector()

    # Get regions from config
    regions = config['data_collection']['regions']
    interval = config['data_collection']['collection_interval']

    # Collect data for first region (you can modify to collect all)
    region_name = list(regions.keys())[0]
    bbox = regions[region_name]

    logger.info(f"\n{'='*60}")
    logger.info(f"FLIGHT DATA COLLECTION STARTING")
    logger.info(f"Region: {region_name}")
    logger.info(f"Bounding Box: {bbox}")
    logger.info(f"{'='*60}\n")

    # Collect for 30 minutes (you can adjust)
    collector.collect_flights_region(
        region_name=region_name,
        bbox=tuple(bbox),
        duration_minutes=30,
        interval_seconds=interval
    )

    # Show summary
    df = collector.get_dataframe()
    print("\n" + "="*60)
    print("COLLECTION SUMMARY")
    print("="*60)
    print(f"\nTotal records collected: {len(df)}")
    print(f"\nUnique aircraft: {df['icao24'].nunique()}")
    print(f"\nCountries represented:")
    print(df['origin_country'].value_counts().head(10))
    print(f"\nData sample:")
    print(df[['timestamp', 'callsign', 'origin_country', 'latitude', 'longitude',
              'baro_altitude', 'velocity', 'on_ground']].head(10))


if __name__ == "__main__":
    # Create logs directory
    os.makedirs('logs', exist_ok=True)

    main()
