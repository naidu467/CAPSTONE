"""
Weather Data Collector using OpenWeatherMap API
Collects weather conditions for major airports
"""

import time
import pandas as pd
import numpy as np
from datetime import datetime
from typing import List, Dict, Optional
import requests
import logging
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class WeatherCollector:
    """
    Collects weather data for airport locations

    Features:
    - Current weather conditions
    - Temperature, humidity, wind speed, pressure
    - Visibility and weather descriptions
    - Mock data when API key not available
    """

    BASE_URL = "http://api.openweathermap.org/data/2.5/weather"

    # Major airport coordinates
    AIRPORT_COORDS = {
        'KJFK': {'name': 'New York JFK', 'lat': 40.6413, 'lon': -73.7781},
        'KLAX': {'name': 'Los Angeles', 'lat': 33.9416, 'lon': -118.4085},
        'KORD': {'name': 'Chicago O\'Hare', 'lat': 41.9742, 'lon': -87.9073},
        'KATL': {'name': 'Atlanta', 'lat': 33.6407, 'lon': -84.4277},
        'KDFW': {'name': 'Dallas', 'lat': 32.8998, 'lon': -97.0403},
        'KSFO': {'name': 'San Francisco', 'lat': 37.6213, 'lon': -122.3790},
        'KDEN': {'name': 'Denver', 'lat': 39.8561, 'lon': -104.6737},
        'KLAS': {'name': 'Las Vegas', 'lat': 36.0840, 'lon': -115.1537},
    }

    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize Weather Collector

        Args:
            api_key: OpenWeatherMap API key (optional)
        """
        self.api_key = api_key or os.getenv('OPENWEATHERMAP_API_KEY')
        self.session = requests.Session()
        self.weather_history = []

        # Create data directory
        os.makedirs('data/raw', exist_ok=True)

        if self.api_key:
            logger.info("WeatherCollector initialized with API key")
        else:
            logger.warning("No API key found - will use mock weather data")

    def get_weather(self, airport_code: str) -> Optional[Dict]:
        """
        Get current weather for an airport

        Args:
            airport_code: Airport ICAO code (e.g., 'KJFK')

        Returns:
            Dictionary with weather data
        """
        if airport_code not in self.AIRPORT_COORDS:
            logger.error(f"Unknown airport code: {airport_code}")
            return None

        airport_info = self.AIRPORT_COORDS[airport_code]

        if self.api_key:
            return self._get_real_weather(airport_code, airport_info)
        else:
            return self._get_mock_weather(airport_code, airport_info)

    def _get_real_weather(self, airport_code: str, airport_info: Dict) -> Optional[Dict]:
        """
        Get real weather data from OpenWeatherMap API

        Args:
            airport_code: Airport code
            airport_info: Airport information dictionary

        Returns:
            Weather data dictionary
        """
        params = {
            'lat': airport_info['lat'],
            'lon': airport_info['lon'],
            'appid': self.api_key,
            'units': 'metric'
        }

        try:
            response = self.session.get(self.BASE_URL, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()
                return self._parse_weather_data(airport_code, data)
            else:
                logger.error(f"API error for {airport_code}: {response.status_code}")
                return self._get_mock_weather(airport_code, airport_info)

        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed for {airport_code}: {str(e)}")
            return self._get_mock_weather(airport_code, airport_info)

    def _parse_weather_data(self, airport_code: str, data: Dict) -> Dict:
        """
        Parse OpenWeatherMap API response

        Args:
            airport_code: Airport code
            data: API response data

        Returns:
            Parsed weather dictionary
        """
        return {
            'timestamp': datetime.now(),
            'airport_code': airport_code,
            'airport_name': self.AIRPORT_COORDS[airport_code]['name'],
            'temperature': data['main']['temp'],  # Celsius
            'feels_like': data['main']['feels_like'],
            'temp_min': data['main']['temp_min'],
            'temp_max': data['main']['temp_max'],
            'pressure': data['main']['pressure'],  # hPa
            'humidity': data['main']['humidity'],  # %
            'visibility': data.get('visibility', 10000),  # meters
            'wind_speed': data['wind']['speed'],  # m/s
            'wind_deg': data['wind'].get('deg', 0),
            'wind_gust': data['wind'].get('gust', data['wind']['speed']),
            'clouds': data['clouds']['all'],  # %
            'weather_main': data['weather'][0]['main'],
            'weather_description': data['weather'][0]['description'],
            'rain_1h': data.get('rain', {}).get('1h', 0),
            'snow_1h': data.get('snow', {}).get('1h', 0),
        }

    def _get_mock_weather(self, airport_code: str, airport_info: Dict) -> Dict:
        """
        Generate mock weather data for testing without API key

        Args:
            airport_code: Airport code
            airport_info: Airport information

        Returns:
            Mock weather data dictionary
        """
        # Generate realistic mock data based on location and time
        hour = datetime.now().hour
        base_temp = 20  # Base temperature in Celsius

        # Add some variation based on time of day
        temp_variation = 5 * np.sin((hour - 6) * np.pi / 12)

        # Add random noise
        np.random.seed(int(time.time()) % 10000)

        return {
            'timestamp': datetime.now(),
            'airport_code': airport_code,
            'airport_name': airport_info['name'],
            'temperature': base_temp + temp_variation + np.random.randn() * 2,
            'feels_like': base_temp + temp_variation + np.random.randn() * 2,
            'temp_min': base_temp + temp_variation - 3,
            'temp_max': base_temp + temp_variation + 3,
            'pressure': 1013 + np.random.randn() * 10,
            'humidity': max(20, min(100, 60 + np.random.randn() * 15)),
            'visibility': max(1000, 10000 + np.random.randn() * 2000),
            'wind_speed': max(0, 5 + np.random.randn() * 3),
            'wind_deg': np.random.randint(0, 360),
            'wind_gust': max(0, 7 + np.random.randn() * 4),
            'clouds': max(0, min(100, 50 + np.random.randn() * 30)),
            'weather_main': np.random.choice(['Clear', 'Clouds', 'Rain'], p=[0.6, 0.3, 0.1]),
            'weather_description': 'clear sky',
            'rain_1h': 0 if np.random.rand() > 0.1 else np.random.rand() * 5,
            'snow_1h': 0,
        }

    def collect_all_airports(self) -> List[Dict]:
        """
        Collect weather data for all airports

        Returns:
            List of weather data dictionaries
        """
        weather_data = []

        for airport_code in self.AIRPORT_COORDS.keys():
            logger.info(f"Collecting weather for {airport_code}")
            weather = self.get_weather(airport_code)

            if weather:
                weather_data.append(weather)
                self.weather_history.append(weather)

                # Print summary
                print(f"{airport_code} ({weather['airport_name']}): "
                      f"{weather['temperature']:.1f}°C, "
                      f"{weather['weather_main']}, "
                      f"Wind: {weather['wind_speed']:.1f} m/s")

            time.sleep(0.5)  # Small delay between requests

        return weather_data

    def save_data(self):
        """Save collected weather data to CSV"""
        if not self.weather_history:
            logger.warning("No weather data to save")
            return

        df = pd.DataFrame(self.weather_history)

        # Create filename with timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"data/raw/weather_{timestamp}.csv"

        df.to_csv(filename, index=False)
        logger.info(f"Saved {len(df)} weather records to {filename}")

        # Also save as latest
        latest_filename = "data/raw/weather_latest.csv"
        df.to_csv(latest_filename, index=False)

    def get_dataframe(self) -> pd.DataFrame:
        """Get collected weather data as DataFrame"""
        return pd.DataFrame(self.weather_history)


def main():
    """
    Main function to demonstrate weather data collection
    """
    logger.info("\n" + "="*60)
    logger.info("WEATHER DATA COLLECTION STARTING")
    logger.info("="*60 + "\n")

    # Create collector
    collector = WeatherCollector()

    # Collect weather for all airports
    weather_data = collector.collect_all_airports()

    # Save data
    collector.save_data()

    # Show summary
    df = collector.get_dataframe()
    print("\n" + "="*60)
    print("WEATHER COLLECTION SUMMARY")
    print("="*60)
    print(f"\nRecords collected: {len(df)}")
    print(f"\nAirports covered: {df['airport_code'].nunique()}")
    print("\nWeather Statistics:")
    print(df[['airport_name', 'temperature', 'humidity', 'wind_speed', 'visibility']].describe())


if __name__ == "__main__":
    # Create logs directory
    os.makedirs('logs', exist_ok=True)

    main()
