"""
Real-Time Flight Delay Prediction
Load trained model and make predictions on streaming data
"""

import pandas as pd
import numpy as np
import joblib
import logging
from datetime import datetime
from typing import Dict, List, Optional
import os
import sys
from pathlib import Path

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent.parent))

from src.data_collection.flight_collector import FlightCollector
from src.data_collection.weather_collector import WeatherCollector
from src.preprocessing.feature_engineering import FeatureEngineer

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DelayPredictor:
    """
    Real-time flight delay predictor

    Loads trained model and makes predictions on new flight data
    """

    def __init__(self, model_path: str = None):
        """
        Initialize predictor

        Args:
            model_path: Path to saved model (optional)
        """
        self.model = None
        self.scaler = None
        self.feature_names = []
        self.engineer = FeatureEngineer()

        # Load model
        if model_path:
            self.load_model(model_path)
        else:
            self.load_best_model()

    def load_best_model(self):
        """Load the best trained model"""
        model_dir = 'data/models'

        # Find available models
        model_files = [f for f in os.listdir(model_dir) if f.endswith('_model.pkl')]

        if not model_files:
            logger.error("No trained models found! Please train a model first.")
            return False

        # Load first available model
        model_path = os.path.join(model_dir, model_files[0])
        return self.load_model(model_path)

    def load_model(self, model_path: str) -> bool:
        """
        Load trained model and associated files

        Args:
            model_path: Path to model file

        Returns:
            True if successful
        """
        try:
            # Load model
            self.model = joblib.load(model_path)
            logger.info(f"Loaded model from {model_path}")

            # Load scaler
            scaler_path = 'data/models/scaler.pkl'
            if os.path.exists(scaler_path):
                self.scaler = joblib.load(scaler_path)
                logger.info("Loaded scaler")

            # Load feature names
            feature_path = 'data/models/feature_names.pkl'
            if os.path.exists(feature_path):
                self.feature_names = joblib.load(feature_path)
                logger.info(f"Loaded {len(self.feature_names)} feature names")

            return True

        except Exception as e:
            logger.error(f"Error loading model: {str(e)}")
            return False

    def preprocess_flight_data(self, flight_data: Dict, weather_data: Dict = None) -> pd.DataFrame:
        """
        Preprocess raw flight data for prediction

        Args:
            flight_data: Flight data dictionary
            weather_data: Weather data dictionary (optional)

        Returns:
            DataFrame ready for prediction
        """
        # Convert to DataFrame
        df = pd.DataFrame([flight_data])

        # Add weather data if available
        if weather_data:
            for key, value in weather_data.items():
                if key not in df.columns:
                    df[key] = value

        # Apply feature engineering
        df, _ = self.engineer.prepare_features(df, create_labels=False)

        return df

    def predict(self, flight_data: Dict, weather_data: Dict = None) -> Dict:
        """
        Predict delay for a single flight

        Args:
            flight_data: Flight data dictionary
            weather_data: Weather data dictionary (optional)

        Returns:
            Prediction dictionary with probability and classification
        """
        if self.model is None:
            logger.error("No model loaded!")
            return None

        try:
            # Preprocess data
            df = self.preprocess_flight_data(flight_data, weather_data)

            # Extract features
            X = df[self.feature_names].fillna(0)

            # Scale features
            if self.scaler:
                X_scaled = self.scaler.transform(X)
            else:
                X_scaled = X

            # Make prediction
            prediction = self.model.predict(X_scaled)[0]
            probability = self.model.predict_proba(X_scaled)[0]

            result = {
                'is_delayed': bool(prediction),
                'delay_probability': float(probability[1]),
                'on_time_probability': float(probability[0]),
                'confidence': float(max(probability)),
                'timestamp': datetime.now().isoformat()
            }

            # Add flight identifier
            if 'callsign' in flight_data:
                result['callsign'] = flight_data['callsign']
            if 'icao24' in flight_data:
                result['icao24'] = flight_data['icao24']

            return result

        except Exception as e:
            logger.error(f"Prediction error: {str(e)}")
            return None

    def predict_batch(self, flights_df: pd.DataFrame, weather_df: pd.DataFrame = None) -> pd.DataFrame:
        """
        Predict delays for multiple flights

        Args:
            flights_df: DataFrame with flight data
            weather_df: DataFrame with weather data (optional)

        Returns:
            DataFrame with predictions
        """
        if self.model is None:
            logger.error("No model loaded!")
            return None

        try:
            # Merge with weather data if available
            if weather_df is not None:
                df = self.engineer.merge_flight_weather(flights_df, weather_df)
            else:
                df = flights_df.copy()

            # Apply feature engineering
            df, _ = self.engineer.prepare_features(df, create_labels=False)

            # Extract features
            X = df[self.feature_names].fillna(0)

            # Scale features
            if self.scaler:
                X_scaled = self.scaler.transform(X)
            else:
                X_scaled = X

            # Make predictions
            predictions = self.model.predict(X_scaled)
            probabilities = self.model.predict_proba(X_scaled)

            # Add predictions to DataFrame
            df['predicted_delay'] = predictions
            df['delay_probability'] = probabilities[:, 1]
            df['on_time_probability'] = probabilities[:, 0]
            df['prediction_time'] = datetime.now()

            logger.info(f"Predicted delays for {len(df)} flights")
            logger.info(f"Predicted delays: {predictions.sum()} ({predictions.mean():.1%})")

            return df

        except Exception as e:
            logger.error(f"Batch prediction error: {str(e)}")
            return None


class RealTimePredictor:
    """
    Real-time streaming prediction system

    Continuously collects data and makes predictions
    """

    def __init__(self):
        """Initialize real-time predictor"""
        self.flight_collector = FlightCollector()
        self.weather_collector = WeatherCollector()
        self.predictor = DelayPredictor()

        self.predictions_history = []

    def run_prediction_cycle(self, bbox: tuple, airport_codes: List[str] = None):
        """
        Run one prediction cycle

        Args:
            bbox: Bounding box for flight collection
            airport_codes: List of airport codes for weather

        Returns:
            DataFrame with predictions
        """
        logger.info(f"\n{'='*60}")
        logger.info(f"PREDICTION CYCLE - {datetime.now()}")
        logger.info(f"{'='*60}\n")

        # Collect flight data
        logger.info("Collecting flight data...")
        flight_states = self.flight_collector.get_states(bbox=bbox)

        if not flight_states:
            logger.warning("No flight data collected")
            return None

        flights_df = pd.DataFrame(flight_states)
        logger.info(f"Collected {len(flights_df)} flights")

        # Collect weather data
        logger.info("Collecting weather data...")
        weather_data = self.weather_collector.collect_all_airports()
        weather_df = pd.DataFrame(weather_data) if weather_data else None

        if weather_df is not None:
            logger.info(f"Collected weather for {len(weather_df)} locations")

        # Make predictions
        logger.info("Making predictions...")
        predictions_df = self.predictor.predict_batch(flights_df, weather_df)

        if predictions_df is not None:
            # Filter to flights in air
            in_flight = predictions_df[predictions_df['in_flight'] == 1]

            # Show summary
            logger.info(f"\n{'='*60}")
            logger.info("PREDICTION SUMMARY")
            logger.info(f"{'='*60}")
            logger.info(f"Total flights analyzed: {len(predictions_df)}")
            logger.info(f"Flights in air: {len(in_flight)}")

            if len(in_flight) > 0:
                delayed = in_flight[in_flight['predicted_delay'] == 1]
                logger.info(f"Predicted delays: {len(delayed)} ({len(delayed)/len(in_flight):.1%})")

                # Show most likely delays
                logger.info(f"\nTop 5 Most Likely Delays:")
                top_delays = in_flight.nlargest(5, 'delay_probability')[
                    ['callsign', 'origin_country', 'altitude_ft', 'velocity_knots',
                     'delay_probability']
                ]
                print(top_delays.to_string(index=False))

            # Save predictions
            self.predictions_history.append(predictions_df)

        return predictions_df

    def save_predictions(self):
        """Save prediction history"""
        if not self.predictions_history:
            logger.warning("No predictions to save")
            return

        # Combine all predictions
        all_predictions = pd.concat(self.predictions_history, ignore_index=True)

        # Save to CSV
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"data/processed/predictions_{timestamp}.csv"
        all_predictions.to_csv(filename, index=False)
        logger.info(f"Saved {len(all_predictions)} predictions to {filename}")


def main():
    """
    Demo real-time prediction
    """
    logger.info("\n" + "="*60)
    logger.info("REAL-TIME FLIGHT DELAY PREDICTION")
    logger.info("="*60 + "\n")

    # Create predictor
    predictor = RealTimePredictor()

    # Define region (US East Coast)
    bbox = (30, 50, -90, -70)

    # Run prediction cycle
    predictions = predictor.run_prediction_cycle(bbox)

    if predictions is not None:
        # Save results
        predictor.save_predictions()

        logger.info("\n" + "="*60)
        logger.info("PREDICTION COMPLETE")
        logger.info("="*60)
        logger.info("\nPredictions saved to data/processed/")


if __name__ == "__main__":
    main()
