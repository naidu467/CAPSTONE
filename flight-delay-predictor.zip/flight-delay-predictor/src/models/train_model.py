"""
Train Machine Learning Models for Flight Delay Prediction
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, confusion_matrix,
                             classification_report)
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import lightgbm as lgb
from imblearn.over_sampling import SMOTE
import joblib
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import logging
import os
import sys
from pathlib import Path

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent.parent))

from src.preprocessing.feature_engineering import FeatureEngineer

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DelayPredictionModel:
    """
    Train and evaluate flight delay prediction models

    Models:
    - Random Forest
    - XGBoost
    - LightGBM
    - Ensemble
    """

    def __init__(self, random_state: int = 42):
        """
        Initialize model trainer

        Args:
            random_state: Random seed for reproducibility
        """
        self.random_state = random_state
        self.models = {}
        self.scaler = StandardScaler()
        self.feature_names = []
        self.best_model = None
        self.best_model_name = None

        # Create output directories
        os.makedirs('data/models', exist_ok=True)
        os.makedirs('data/processed', exist_ok=True)

    def load_data(self, filepath: str) -> pd.DataFrame:
        """
        Load processed data

        Args:
            filepath: Path to CSV file

        Returns:
            DataFrame with processed data
        """
        logger.info(f"Loading data from {filepath}")
        df = pd.read_csv(filepath)
        logger.info(f"Loaded {len(df)} records")
        return df

    def prepare_data(self, df: pd.DataFrame, feature_cols: list,
                     target_col: str = 'is_delayed',
                     test_size: float = 0.2,
                     use_smote: bool = True):
        """
        Prepare data for training

        Args:
            df: Input DataFrame
            feature_cols: List of feature column names
            target_col: Target column name
            test_size: Test set size
            use_smote: Whether to use SMOTE for class balancing

        Returns:
            Tuple of (X_train, X_test, y_train, y_test)
        """
        logger.info("Preparing data for training...")

        # Remove rows with missing values in feature columns
        df_clean = df[feature_cols + [target_col]].dropna()
        logger.info(f"Cleaned data shape: {df_clean.shape}")

        # Separate features and target
        X = df_clean[feature_cols]
        y = df_clean[target_col]

        self.feature_names = feature_cols

        # Train-test split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=self.random_state, stratify=y
        )

        logger.info(f"Train set: {X_train.shape}, Test set: {X_test.shape}")
        logger.info(f"Class distribution - Train: {y_train.value_counts().to_dict()}")
        logger.info(f"Class distribution - Test: {y_test.value_counts().to_dict()}")

        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        # Handle class imbalance with SMOTE
        if use_smote and y_train.value_counts().min() > 1:
            logger.info("Applying SMOTE for class balancing...")
            smote = SMOTE(random_state=self.random_state)
            X_train_scaled, y_train = smote.fit_resample(X_train_scaled, y_train)
            logger.info(f"After SMOTE: {X_train_scaled.shape}")
            logger.info(f"Class distribution after SMOTE: {pd.Series(y_train).value_counts().to_dict()}")

        return X_train_scaled, X_test_scaled, y_train, y_test

    def train_random_forest(self, X_train, y_train) -> RandomForestClassifier:
        """
        Train Random Forest model

        Args:
            X_train: Training features
            y_train: Training labels

        Returns:
            Trained RandomForestClassifier
        """
        logger.info("Training Random Forest...")

        model = RandomForestClassifier(
            n_estimators=200,
            max_depth=15,
            min_samples_split=10,
            min_samples_leaf=5,
            random_state=self.random_state,
            n_jobs=-1,
            class_weight='balanced'
        )

        model.fit(X_train, y_train)
        logger.info("Random Forest training complete")

        return model

    def train_xgboost(self, X_train, y_train) -> xgb.XGBClassifier:
        """
        Train XGBoost model

        Args:
            X_train: Training features
            y_train: Training labels

        Returns:
            Trained XGBClassifier
        """
        logger.info("Training XGBoost...")

        model = xgb.XGBClassifier(
            n_estimators=200,
            max_depth=7,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=self.random_state,
            n_jobs=-1,
            eval_metric='logloss'
        )

        model.fit(X_train, y_train)
        logger.info("XGBoost training complete")

        return model

    def train_lightgbm(self, X_train, y_train) -> lgb.LGBMClassifier:
        """
        Train LightGBM model

        Args:
            X_train: Training features
            y_train: Training labels

        Returns:
            Trained LGBMClassifier
        """
        logger.info("Training LightGBM...")

        model = lgb.LGBMClassifier(
            n_estimators=200,
            max_depth=7,
            learning_rate=0.1,
            num_leaves=31,
            random_state=self.random_state,
            n_jobs=-1,
            verbose=-1
        )

        model.fit(X_train, y_train)
        logger.info("LightGBM training complete")

        return model

    def train_all_models(self, X_train, X_test, y_train, y_test):
        """
        Train all models and compare performance

        Args:
            X_train: Training features
            X_test: Test features
            y_train: Training labels
            y_test: Test labels
        """
        logger.info("\n" + "="*60)
        logger.info("TRAINING ALL MODELS")
        logger.info("="*60 + "\n")

        # Train models
        self.models['Random Forest'] = self.train_random_forest(X_train, y_train)
        self.models['XGBoost'] = self.train_xgboost(X_train, y_train)
        self.models['LightGBM'] = self.train_lightgbm(X_train, y_train)

        # Evaluate all models
        results = []
        best_score = 0

        for name, model in self.models.items():
            logger.info(f"\n{name} Evaluation:")
            logger.info("-" * 40)

            # Predictions
            y_pred = model.predict(X_test)
            y_pred_proba = model.predict_proba(X_test)[:, 1]

            # Metrics
            metrics = {
                'Model': name,
                'Accuracy': accuracy_score(y_test, y_pred),
                'Precision': precision_score(y_test, y_pred, zero_division=0),
                'Recall': recall_score(y_test, y_pred, zero_division=0),
                'F1-Score': f1_score(y_test, y_pred, zero_division=0),
                'ROC-AUC': roc_auc_score(y_test, y_pred_proba)
            }

            results.append(metrics)

            # Print metrics
            for metric, value in metrics.items():
                if metric != 'Model':
                    logger.info(f"{metric}: {value:.4f}")

            # Track best model
            if metrics['F1-Score'] > best_score:
                best_score = metrics['F1-Score']
                self.best_model = model
                self.best_model_name = name

            # Print classification report
            logger.info("\nClassification Report:")
            print(classification_report(y_test, y_pred, target_names=['On-Time', 'Delayed']))

            # Confusion matrix
            cm = confusion_matrix(y_test, y_pred)
            logger.info(f"\nConfusion Matrix:\n{cm}")

        # Compare results
        results_df = pd.DataFrame(results)
        logger.info("\n" + "="*60)
        logger.info("MODEL COMPARISON")
        logger.info("="*60)
        print("\n", results_df.to_string(index=False))

        logger.info(f"\nBest Model: {self.best_model_name} (F1-Score: {best_score:.4f})")

        # Save results
        results_df.to_csv('data/models/model_comparison.csv', index=False)

        return results_df

    def plot_feature_importance(self, model, model_name: str):
        """
        Plot feature importance

        Args:
            model: Trained model
            model_name: Name of the model
        """
        if hasattr(model, 'feature_importances_'):
            importances = model.feature_importances_
            indices = np.argsort(importances)[::-1]

            plt.figure(figsize=(12, 8))
            plt.title(f'Feature Importances - {model_name}')
            plt.bar(range(len(importances)), importances[indices])
            plt.xticks(range(len(importances)),
                      [self.feature_names[i] for i in indices],
                      rotation=45, ha='right')
            plt.xlabel('Features')
            plt.ylabel('Importance')
            plt.tight_layout()

            filename = f'data/models/feature_importance_{model_name.replace(" ", "_")}.png'
            plt.savefig(filename)
            logger.info(f"Saved feature importance plot: {filename}")
            plt.close()

    def plot_confusion_matrix(self, y_test, y_pred, model_name: str):
        """
        Plot confusion matrix

        Args:
            y_test: True labels
            y_pred: Predicted labels
            model_name: Name of the model
        """
        cm = confusion_matrix(y_test, y_pred)

        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                   xticklabels=['On-Time', 'Delayed'],
                   yticklabels=['On-Time', 'Delayed'])
        plt.title(f'Confusion Matrix - {model_name}')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.tight_layout()

        filename = f'data/models/confusion_matrix_{model_name.replace(" ", "_")}.png'
        plt.savefig(filename)
        logger.info(f"Saved confusion matrix: {filename}")
        plt.close()

    def save_model(self, model_name: str = None):
        """
        Save trained model

        Args:
            model_name: Name of model to save (default: best model)
        """
        if model_name is None:
            model = self.best_model
            name = self.best_model_name
        else:
            model = self.models.get(model_name)
            name = model_name

        if model is None:
            logger.error(f"Model {name} not found")
            return

        # Save model
        model_path = f'data/models/{name.replace(" ", "_").lower()}_model.pkl'
        joblib.dump(model, model_path)
        logger.info(f"Saved model: {model_path}")

        # Save scaler
        scaler_path = 'data/models/scaler.pkl'
        joblib.dump(self.scaler, scaler_path)
        logger.info(f"Saved scaler: {scaler_path}")

        # Save feature names
        feature_path = 'data/models/feature_names.pkl'
        joblib.dump(self.feature_names, feature_path)
        logger.info(f"Saved feature names: {feature_path}")


def main():
    """
    Main training pipeline
    """
    logger.info("\n" + "="*60)
    logger.info("FLIGHT DELAY PREDICTION MODEL TRAINING")
    logger.info("="*60 + "\n")

    # Check if processed data exists
    processed_file = 'data/processed/sample_features.csv'

    if not os.path.exists(processed_file):
        logger.info("No processed data found. Creating sample data...")

        # Create sample data using FeatureEngineer
        from src.preprocessing.feature_engineering import main as create_features
        create_features()

    # Load data
    trainer = DelayPredictionModel()
    df = trainer.load_data(processed_file)

    # Define features
    feature_cols = [
        'hour', 'day_of_week', 'month', 'is_weekend', 'is_peak_hour',
        'altitude_ft', 'velocity_knots', 'vertical_rate', 'in_flight',
        'temperature', 'humidity', 'pressure', 'wind_speed',
        'visibility', 'clouds', 'bad_weather'
    ]

    # Filter to existing columns
    feature_cols = [col for col in feature_cols if col in df.columns]
    logger.info(f"Using {len(feature_cols)} features: {feature_cols}")

    # Prepare data
    X_train, X_test, y_train, y_test = trainer.prepare_data(
        df, feature_cols, use_smote=True
    )

    # Train all models
    results = trainer.train_all_models(X_train, X_test, y_train, y_test)

    # Plot feature importance for best model
    trainer.plot_feature_importance(trainer.best_model, trainer.best_model_name)

    # Plot confusion matrix for best model
    y_pred = trainer.best_model.predict(X_test)
    trainer.plot_confusion_matrix(y_test, y_pred, trainer.best_model_name)

    # Save best model
    trainer.save_model()

    logger.info("\n" + "="*60)
    logger.info("TRAINING COMPLETE")
    logger.info("="*60)
    logger.info(f"\nBest model ({trainer.best_model_name}) saved to data/models/")
    logger.info("You can now use this model for real-time predictions!")


if __name__ == "__main__":
    main()
