"""
Real-Time Flight Delay Prediction Dashboard
Interactive Streamlit dashboard for monitoring flights and predictions
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import time
import sys
from pathlib import Path

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent.parent))

from src.models.predict import RealTimePredictor

# Page configuration
st.set_page_config(
    page_title="Flight Delay Predictor",
    page_icon="✈️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        text-align: center;
        color: #1f77b4;
        margin-bottom: 1rem;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    .delayed {
        color: #d62728;
        font-weight: bold;
    }
    .on-time {
        color: #2ca02c;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)


class FlightDashboard:
    """Interactive dashboard for flight delay predictions"""

    def __init__(self):
        """Initialize dashboard"""
        self.predictor = None

        # Initialize session state
        if 'predictions' not in st.session_state:
            st.session_state.predictions = None
        if 'last_update' not in st.session_state:
            st.session_state.last_update = None

    def render_header(self):
        """Render dashboard header"""
        st.markdown('<h1 class="main-header">✈️ Real-Time Flight Delay Predictor</h1>',
                   unsafe_allow_html=True)

        st.markdown("""
        <div style='text-align: center; margin-bottom: 2rem;'>
            Monitor live flights and predict delays using machine learning
        </div>
        """, unsafe_allow_html=True)

    def render_sidebar(self):
        """Render sidebar controls"""
        st.sidebar.header("⚙️ Settings")

        # Region selection
        regions = {
            'US East Coast': (30, 50, -90, -70),
            'US West Coast': (30, 50, -125, -110),
            'Europe': (35, 70, -10, 40)
        }

        selected_region = st.sidebar.selectbox(
            "Select Region",
            list(regions.keys())
        )

        # Auto-refresh settings
        auto_refresh = st.sidebar.checkbox("Auto-refresh", value=False)
        refresh_interval = st.sidebar.slider(
            "Refresh interval (seconds)",
            min_value=30,
            max_value=300,
            value=60,
            step=30
        )

        # Manual refresh button
        if st.sidebar.button("🔄 Refresh Now", use_container_width=True):
            st.session_state.refresh_trigger = True

        # Info
        st.sidebar.markdown("---")
        st.sidebar.markdown("### About")
        st.sidebar.info("""
        This dashboard shows real-time flight tracking and delay predictions using:
        - OpenSky Network for live flight data
        - OpenWeatherMap for weather conditions
        - Machine Learning for delay predictions
        """)

        # Last update time
        if st.session_state.last_update:
            st.sidebar.markdown("---")
            st.sidebar.markdown(f"**Last Updated:** {st.session_state.last_update.strftime('%H:%M:%S')}")

        return regions[selected_region], auto_refresh, refresh_interval

    def create_map_visualization(self, df: pd.DataFrame):
        """
        Create interactive map of flights

        Args:
            df: DataFrame with flight predictions
        """
        if df is None or len(df) == 0:
            st.warning("No flight data available")
            return

        # Filter to flights in air with valid coordinates
        map_df = df[(df['in_flight'] == 1) &
                    (df['latitude'].notna()) &
                    (df['longitude'].notna())].copy()

        if len(map_df) == 0:
            st.warning("No flights in air")
            return

        # Add color based on prediction
        map_df['color'] = map_df['predicted_delay'].map({
            0: 'green',
            1: 'red'
        })

        map_df['status'] = map_df['predicted_delay'].map({
            0: 'On-Time',
            1: 'Delayed'
        })

        # Create map
        fig = px.scatter_mapbox(
            map_df,
            lat='latitude',
            lon='longitude',
            color='status',
            color_discrete_map={'On-Time': 'green', 'Delayed': 'red'},
            size='delay_probability',
            size_max=15,
            hover_data={
                'callsign': True,
                'origin_country': True,
                'altitude_ft': ':.0f',
                'velocity_knots': ':.0f',
                'delay_probability': ':.2%',
                'latitude': False,
                'longitude': False,
                'status': False
            },
            zoom=3,
            height=500,
            title="Live Flight Positions"
        )

        fig.update_layout(
            mapbox_style="open-street-map",
            margin={"r": 0, "t": 30, "l": 0, "b": 0}
        )

        st.plotly_chart(fig, use_container_width=True)

    def create_metrics_cards(self, df: pd.DataFrame):
        """
        Create metric cards

        Args:
            df: DataFrame with predictions
        """
        if df is None or len(df) == 0:
            return

        # Filter to flights in air
        in_flight = df[df['in_flight'] == 1]

        if len(in_flight) == 0:
            st.info("No flights currently in air")
            return

        # Calculate metrics
        total_flights = len(in_flight)
        predicted_delays = (in_flight['predicted_delay'] == 1).sum()
        delay_rate = predicted_delays / total_flights if total_flights > 0 else 0
        avg_delay_prob = in_flight['delay_probability'].mean()

        # Display metrics
        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric("Total Flights", f"{total_flights}")

        with col2:
            st.metric("Predicted Delays", f"{predicted_delays}",
                     delta=f"{delay_rate:.1%} delay rate")

        with col3:
            st.metric("Avg Delay Probability", f"{avg_delay_prob:.1%}")

        with col4:
            on_time = total_flights - predicted_delays
            st.metric("On-Time Flights", f"{on_time}",
                     delta=f"{(1-delay_rate):.1%} on-time rate")

    def create_delay_distribution(self, df: pd.DataFrame):
        """
        Create delay probability distribution chart

        Args:
            df: DataFrame with predictions
        """
        if df is None or len(df) == 0:
            return

        in_flight = df[df['in_flight'] == 1]

        if len(in_flight) == 0:
            return

        # Create histogram
        fig = px.histogram(
            in_flight,
            x='delay_probability',
            nbins=20,
            title="Delay Probability Distribution",
            labels={'delay_probability': 'Delay Probability', 'count': 'Number of Flights'},
            color_discrete_sequence=['#1f77b4']
        )

        fig.add_vline(x=0.5, line_dash="dash", line_color="red",
                     annotation_text="Decision Threshold")

        fig.update_layout(height=400)
        st.plotly_chart(fig, use_container_width=True)

    def create_flight_table(self, df: pd.DataFrame):
        """
        Create table of flights with predictions

        Args:
            df: DataFrame with predictions
        """
        if df is None or len(df) == 0:
            return

        # Filter and sort
        in_flight = df[df['in_flight'] == 1].copy()

        if len(in_flight) == 0:
            st.info("No flights currently in air")
            return

        # Select columns to display
        display_cols = [
            'callsign', 'origin_country', 'altitude_ft', 'velocity_knots',
            'delay_probability', 'predicted_delay'
        ]

        display_df = in_flight[display_cols].copy()

        # Format columns
        display_df['altitude_ft'] = display_df['altitude_ft'].round(0).astype(int)
        display_df['velocity_knots'] = display_df['velocity_knots'].round(0).astype(int)
        display_df['delay_probability'] = (display_df['delay_probability'] * 100).round(1)
        display_df['predicted_delay'] = display_df['predicted_delay'].map({
            0: '✅ On-Time',
            1: '❌ Delayed'
        })

        # Rename columns
        display_df.columns = [
            'Callsign', 'Country', 'Altitude (ft)', 'Speed (knots)',
            'Delay Prob (%)', 'Prediction'
        ]

        # Sort by delay probability
        display_df = display_df.sort_values('Delay Prob (%)', ascending=False)

        st.dataframe(
            display_df,
            use_container_width=True,
            height=400
        )

    def create_weather_summary(self, df: pd.DataFrame):
        """
        Create weather conditions summary

        Args:
            df: DataFrame with weather data
        """
        if df is None or len(df) == 0 or 'temperature' not in df.columns:
            return

        st.subheader("🌤️ Weather Conditions")

        # Get unique weather readings
        weather_cols = ['temperature', 'humidity', 'wind_speed', 'visibility', 'bad_weather']
        weather_cols = [col for col in weather_cols if col in df.columns]

        if not weather_cols:
            return

        # Calculate averages
        weather_summary = df[weather_cols].mean()

        col1, col2, col3, col4 = st.columns(4)

        with col1:
            if 'temperature' in weather_summary:
                st.metric("Temperature", f"{weather_summary['temperature']:.1f}°C")

        with col2:
            if 'humidity' in weather_summary:
                st.metric("Humidity", f"{weather_summary['humidity']:.0f}%")

        with col3:
            if 'wind_speed' in weather_summary:
                st.metric("Wind Speed", f"{weather_summary['wind_speed']:.1f} m/s")

        with col4:
            if 'bad_weather' in weather_summary:
                bad_weather_pct = weather_summary['bad_weather'] * 100
                st.metric("Bad Weather", f"{bad_weather_pct:.0f}%")

    def run_prediction(self, bbox: tuple):
        """
        Run prediction cycle

        Args:
            bbox: Bounding box for region
        """
        with st.spinner("Collecting flight data and making predictions..."):
            try:
                # Initialize predictor if needed
                if self.predictor is None:
                    self.predictor = RealTimePredictor()

                # Run prediction
                predictions = self.predictor.run_prediction_cycle(bbox)

                if predictions is not None:
                    st.session_state.predictions = predictions
                    st.session_state.last_update = datetime.now()
                    return True
                else:
                    st.error("Failed to collect data or make predictions")
                    return False

            except Exception as e:
                st.error(f"Error during prediction: {str(e)}")
                return False

    def render(self):
        """Main render function"""
        # Header
        self.render_header()

        # Sidebar
        bbox, auto_refresh, refresh_interval = self.render_sidebar()

        # Initial load or manual refresh
        if st.session_state.predictions is None or st.session_state.get('refresh_trigger', False):
            self.run_prediction(bbox)
            st.session_state.refresh_trigger = False

        # Display results
        if st.session_state.predictions is not None:
            df = st.session_state.predictions

            # Metrics
            self.create_metrics_cards(df)

            # Main content
            col1, col2 = st.columns([2, 1])

            with col1:
                st.subheader("📍 Live Flight Map")
                self.create_map_visualization(df)

            with col2:
                st.subheader("📊 Statistics")
                self.create_delay_distribution(df)

            # Weather summary
            self.create_weather_summary(df)

            # Flight table
            st.subheader("✈️ Flight List")
            self.create_flight_table(df)

        # Auto-refresh
        if auto_refresh:
            time.sleep(refresh_interval)
            st.rerun()


def main():
    """Main entry point"""
    dashboard = FlightDashboard()
    dashboard.render()


if __name__ == "__main__":
    main()
