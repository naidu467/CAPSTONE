"""
Feature Engineering for Flight Delay Prediction
Creates features from raw flight and weather data
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Tuple, Optional
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class FeatureEngineer:
    """
    Feature engineering for flight delay prediction

    Features created:
    - Time-based features (hour, day, month, day_of_week)
    - Flight characteristics (altitude, velocity, vertical_rate)
    - Weather features (temperature, wind, visibility)
    - Derived features (wind_effect, altitude_band, time_of_day)
    """

    def __init__(self):
        """Initialize Feature Engineer"""
        self.feature_names = []

    def create_time_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create time-based features

        Args:
            df: DataFrame with 'timestamp' column

        Returns:
            DataFrame with additional time features
        """
        logger.info("Creating time features...")

        # Ensure timestamp is datetime
        if not pd.api.types.is_datetime64_any_dtype(df['timestamp']):
            df['timestamp'] = pd.to_datetime(df['timestamp'])

        # Extract time components
        df['hour'] = df['timestamp'].dt.hour
        df['day'] = df['timestamp'].dt.day
        df['month'] = df['timestamp'].dt.month
        df['day_of_week'] = df['timestamp'].dt.dayofweek
        df['day_of_year'] = df['timestamp'].dt.dayofyear
        df['week_of_year'] = df['timestamp'].dt.isocalendar().week

        # Time of day categories
        df['time_of_day'] = pd.cut(
            df['hour'],
            bins=[0, 6, 12, 18, 24],
            labels=['night', 'morning', 'afternoon', 'evening'],
            include_lowest=True
        )

        # Weekend flag
        df['is_weekend'] = (df['day_of_week'] >= 5).astype(int)

        # Peak hour flag (7-9 AM, 5-7 PM)
        df['is_peak_hour'] = ((df['hour'].between(7, 9)) | (df['hour'].between(17, 19))).astype(int)

        logger.info(f"Created {8} time features")
        return df

    def create_flight_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create flight-specific features

        Args:
            df: DataFrame with flight data

        Returns:
            DataFrame with additional flight features
        """
        logger.info("Creating flight features...")

        # Altitude features (convert to feet if in meters)
        if 'baro_altitude' in df.columns:
            # Convert meters to feet
            df['altitude_ft'] = df['baro_altitude'] * 3.28084

            # Altitude bands
            df['altitude_band'] = pd.cut(
                df['altitude_ft'],
                bins=[0, 10000, 20000, 30000, 40000, 50000],
                labels=['low', 'medium', 'high', 'very_high', 'extreme']
            )

            # Climbing, cruising, or descending
            if 'vertical_rate' in df.columns:
                df['flight_phase'] = pd.cut(
                    df['vertical_rate'],
                    bins=[-np.inf, -2, 2, np.inf],
                    labels=['descending', 'cruising', 'climbing']
                )

        # Velocity features (convert m/s to knots)
        if 'velocity' in df.columns:
            df['velocity_knots'] = df['velocity'] * 1.94384
            df['speed_category'] = pd.cut(
                df['velocity_knots'],
                bins=[0, 150, 300, 450, 600],
                labels=['slow', 'medium', 'fast', 'very_fast']
            )

        # On ground flag
        if 'on_ground' in df.columns:
            df['in_flight'] = (~df['on_ground']).astype(int)

        # Calculate time since last position update
        if 'last_contact' in df.columns and 'time_position' in df.columns:
            df['position_lag'] = df['last_contact'] - df['time_position']

        logger.info(f"Created flight features")
        return df

    def create_weather_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create weather-related features

        Args:
            df: DataFrame with weather data

        Returns:
            DataFrame with additional weather features
        """
        logger.info("Creating weather features...")

        if 'temperature' in df.columns:
            # Temperature categories
            df['temp_category'] = pd.cut(
                df['temperature'],
                bins=[-50, 0, 15, 25, 50],
                labels=['cold', 'cool', 'warm', 'hot']
            )

        if 'wind_speed' in df.columns:
            # Wind categories
            df['wind_category'] = pd.cut(
                df['wind_speed'],
                bins=[0, 5, 10, 15, 100],
                labels=['calm', 'moderate', 'strong', 'severe']
            )

            # Wind effect (combination of speed and altitude)
            if 'altitude_ft' in df.columns:
                # Wind has more effect at lower altitudes
                df['wind_effect'] = df['wind_speed'] * (1 / (1 + df['altitude_ft'] / 10000))

        if 'visibility' in df.columns:
            # Visibility categories (meters)
            df['visibility_category'] = pd.cut(
                df['visibility'],
                bins=[0, 1000, 5000, 10000, np.inf],
                labels=['poor', 'moderate', 'good', 'excellent']
            )

        if 'humidity' in df.columns and 'temperature' in df.columns:
            # Heat index approximation
            df['heat_index'] = df['temperature'] + 0.5 * (df['humidity'] - 50) / 100

        if 'clouds' in df.columns:
            # Cloud coverage categories
            df['cloud_coverage'] = pd.cut(
                df['clouds'],
                bins=[0, 25, 50, 75, 100],
                labels=['clear', 'partly_cloudy', 'mostly_cloudy', 'overcast']
            )

        # Bad weather flag
        df['bad_weather'] = 0
        if 'weather_main' in df.columns:
            bad_weather_conditions = ['Rain', 'Snow', 'Thunderstorm', 'Drizzle']
            df['bad_weather'] = df['weather_main'].isin(bad_weather_conditions).astype(int)

        logger.info(f"Created weather features")
        return df

    def create_delay_label(self, df: pd.DataFrame, delay_threshold: int = 15) -> pd.DataFrame:
        """
        Create delay labels for training

        This is simulated for demonstration. In production, you'd need actual
        scheduled vs actual arrival times.

        Args:
            df: DataFrame with flight data
            delay_threshold: Delay threshold in minutes

        Returns:
            DataFrame with delay label
        """
        logger.info(f"Creating delay labels (threshold: {delay_threshold} min)...")

        # Simulate delays based on conditions
        # In real scenario, you'd compare scheduled vs actual times

        delay_prob = 0.15  # Base 15% delay rate

        # Increase probability based on conditions
        conditions = []

        if 'bad_weather' in df.columns:
            conditions.append(df['bad_weather'] * 0.3)

        if 'is_peak_hour' in df.columns:
            conditions.append(df['is_peak_hour'] * 0.2)

        if 'wind_category' in df.columns:
            wind_effect = (df['wind_category'] == 'strong').astype(int) * 0.15
            conditions.append(wind_effect)

        if 'visibility_category' in df.columns:
            vis_effect = (df['visibility_category'] == 'poor').astype(int) * 0.25
            conditions.append(vis_effect)

        # Calculate combined probability
        if conditions:
            combined_effect = sum(conditions)
            final_prob = np.clip(delay_prob + combined_effect, 0, 0.8)
        else:
            final_prob = delay_prob

        # Generate delays
        np.random.seed(42)
        df['is_delayed'] = (np.random.random(len(df)) < final_prob).astype(int)

        # Generate delay duration for delayed flights
        df['delay_minutes'] = 0
        delayed_mask = df['is_delayed'] == 1
        df.loc[delayed_mask, 'delay_minutes'] = np.random.exponential(30, delayed_mask.sum())

        logger.info(f"Delay rate: {df['is_delayed'].mean():.2%}")
        return df

    def merge_flight_weather(self, flight_df: pd.DataFrame, weather_df: pd.DataFrame) -> pd.DataFrame:
        """
        Merge flight and weather data

        Args:
            flight_df: Flight data DataFrame
            weather_df: Weather data DataFrame

        Returns:
            Merged DataFrame
        """
        logger.info("Merging flight and weather data...")

        # Ensure timestamps are datetime
        flight_df['timestamp'] = pd.to_datetime(flight_df['timestamp'])
        weather_df['timestamp'] = pd.to_datetime(weather_df['timestamp'])

        # For simplicity, use the nearest weather observation
        # In production, you'd want more sophisticated matching

        # Get unique airports from weather data
        if 'airport_code' in weather_df.columns:
            # Match by nearest timestamp
            merged_data = []

            for airport in weather_df['airport_code'].unique():
                airport_weather = weather_df[weather_df['airport_code'] == airport].copy()

                # Merge with tolerance of 1 hour
                merged = pd.merge_asof(
                    flight_df.sort_values('timestamp'),
                    airport_weather.sort_values('timestamp'),
                    on='timestamp',
                    direction='nearest',
                    tolerance=pd.Timedelta('1h'),
                    suffixes=('', '_weather')
                )

                merged_data.append(merged)

            result = pd.concat(merged_data, ignore_index=True)
        else:
            # Simple merge if no airport code
            result = flight_df.copy()
            # Add average weather conditions
            for col in weather_df.columns:
                if col != 'timestamp' and col not in flight_df.columns:
                    result[col] = weather_df[col].mean()

        logger.info(f"Merged data shape: {result.shape}")
        return result

    def prepare_features(self, df: pd.DataFrame, create_labels: bool = True) -> Tuple[pd.DataFrame, list]:
        """
        Complete feature engineering pipeline

        Args:
            df: Input DataFrame
            create_labels: Whether to create delay labels

        Returns:
            Tuple of (processed DataFrame, list of feature names)
        """
        logger.info("Starting feature engineering pipeline...")

        # Create features
        df = self.create_time_features(df)
        df = self.create_flight_features(df)
        df = self.create_weather_features(df)

        # Create labels if requested
        if create_labels:
            df = self.create_delay_label(df)

        # Define feature columns
        feature_cols = [
            # Time features
            'hour', 'day_of_week', 'month', 'is_weekend', 'is_peak_hour',

            # Flight features
            'altitude_ft', 'velocity_knots', 'vertical_rate', 'in_flight',

            # Weather features
            'temperature', 'humidity', 'pressure', 'wind_speed',
            'visibility', 'clouds', 'bad_weather'
        ]

        # Filter to existing columns
        feature_cols = [col for col in feature_cols if col in df.columns]

        self.feature_names = feature_cols
        logger.info(f"Feature engineering complete. {len(feature_cols)} features created.")

        return df, feature_cols

    def get_feature_importance_names(self) -> list:
        """Get list of feature names"""
        return self.feature_names


def main():
    """
    Demonstrate feature engineering
    """
    logger.info("\n" + "="*60)
    logger.info("FEATURE ENGINEERING DEMO")
    logger.info("="*60 + "\n")

    # Create sample data
    n_samples = 1000

    flight_data = pd.DataFrame({
        'timestamp': pd.date_range(start='2024-01-01', periods=n_samples, freq='1H'),
        'icao24': np.random.choice(['abc123', 'def456', 'ghi789'], n_samples),
        'baro_altitude': np.random.uniform(0, 12000, n_samples),
        'velocity': np.random.uniform(50, 250, n_samples),
        'vertical_rate': np.random.uniform(-10, 10, n_samples),
        'on_ground': np.random.choice([True, False], n_samples, p=[0.2, 0.8]),
        'latitude': np.random.uniform(30, 50, n_samples),
        'longitude': np.random.uniform(-120, -70, n_samples),
    })

    weather_data = pd.DataFrame({
        'timestamp': pd.date_range(start='2024-01-01', periods=n_samples//10, freq='10H'),
        'temperature': np.random.uniform(10, 30, n_samples//10),
        'humidity': np.random.uniform(30, 90, n_samples//10),
        'pressure': np.random.uniform(1000, 1025, n_samples//10),
        'wind_speed': np.random.uniform(0, 20, n_samples//10),
        'visibility': np.random.uniform(1000, 10000, n_samples//10),
        'clouds': np.random.uniform(0, 100, n_samples//10),
        'weather_main': np.random.choice(['Clear', 'Clouds', 'Rain'], n_samples//10),
    })

    # Create feature engineer
    engineer = FeatureEngineer()

    # Merge data
    merged_df = engineer.merge_flight_weather(flight_data, weather_data)

    # Prepare features
    processed_df, feature_cols = engineer.prepare_features(merged_df, create_labels=True)

    # Show results
    print("\nProcessed Data Shape:", processed_df.shape)
    print("\nFeature Columns:", feature_cols)
    print("\nSample of engineered features:")
    print(processed_df[feature_cols + ['is_delayed']].head(10))
    print("\nDelay Statistics:")
    print(f"Total flights: {len(processed_df)}")
    print(f"Delayed flights: {processed_df['is_delayed'].sum()}")
    print(f"Delay rate: {processed_df['is_delayed'].mean():.2%}")
    print(f"Average delay (when delayed): {processed_df[processed_df['is_delayed']==1]['delay_minutes'].mean():.1f} minutes")

    # Save sample processed data
    processed_df.to_csv('data/processed/sample_features.csv', index=False)
    print("\nSaved sample processed data to data/processed/sample_features.csv")


if __name__ == "__main__":
    import os
    os.makedirs('data/processed', exist_ok=True)
    main()
