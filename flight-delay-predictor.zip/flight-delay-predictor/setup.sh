#!/bin/bash

# Flight Delay Predictor - Setup Script
# This script sets up the project environment

echo "========================================="
echo "Flight Delay Predictor - Setup"
echo "========================================="
echo ""

# Check Python version
echo "Checking Python version..."
python3 --version

if [ $? -ne 0 ]; then
    echo "Error: Python 3 is not installed"
    exit 1
fi

echo ""
echo "Creating virtual environment..."
python3 -m venv venv

echo ""
echo "Activating virtual environment..."
source venv/bin/activate

echo ""
echo "Upgrading pip..."
pip install --upgrade pip

echo ""
echo "Installing dependencies..."
pip install -r requirements.txt

if [ $? -ne 0 ]; then
    echo "Error: Failed to install dependencies"
    exit 1
fi

echo ""
echo "Creating directory structure..."
mkdir -p data/raw
mkdir -p data/processed
mkdir -p data/models
mkdir -p logs

echo ""
echo "Creating .env file..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo ".env file created. You can add your API keys later."
else
    echo ".env file already exists."
fi

echo ""
echo "========================================="
echo "Setup Complete!"
echo "========================================="
echo ""
echo "Next steps:"
echo "1. Activate the virtual environment:"
echo "   source venv/bin/activate"
echo ""
echo "2. (Optional) Add API keys to .env file"
echo ""
echo "3. Run data collection:"
echo "   python src/data_collection/flight_collector.py"
echo ""
echo "4. Train models:"
echo "   python src/models/train_model.py"
echo ""
echo "5. Launch dashboard:"
echo "   streamlit run src/visualization/dashboard.py"
echo ""
echo "See QUICKSTART.md for detailed instructions."
echo ""
