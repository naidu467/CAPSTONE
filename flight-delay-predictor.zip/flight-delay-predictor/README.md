# ✈️ Real-Time Flight Delay Predictor

A machine learning system that predicts flight delays in real-time using live flight tracking data and weather conditions.

## 🎯 Project Overview

This capstone project demonstrates end-to-end data science capabilities:
- **Real-time data streaming** from OpenSky Network (live flight data)
- **Weather data integration** for enhanced predictions
- **Machine learning models** for delay prediction
- **Interactive dashboard** for real-time monitoring
- **Database storage** for historical analysis

## 🌟 Features

- ✅ Real-time flight tracking across multiple regions
- ✅ Weather condition monitoring for major airports
- ✅ ML-based delay prediction (Random Forest, XGBoost, LightGBM)
- ✅ Interactive Streamlit dashboard
- ✅ Historical data analysis
- ✅ Model performance metrics and visualization

## 📊 Data Sources

### Primary Sources (FREE - No API Key Required)
1. **OpenSky Network API** - Real-time flight positions, altitude, velocity
   - Completely free and open
   - No registration needed for basic usage
   - Updates every 10 seconds

### Secondary Sources (FREE - Optional)
2. **OpenWeatherMap API** - Weather conditions
   - Free tier: 60 calls/minute
   - Sign up at: https://openweathermap.org/api

## 🛠️ Technology Stack

- **Python 3.9+**
- **Data Processing**: Pandas, NumPy
- **Machine Learning**: Scikit-learn, XGBoost, LightGBM
- **Real-time Data**: OpenSky API, Requests, AsyncIO
- **Visualization**: Plotly, Streamlit, Matplotlib
- **Database**: SQLite
- **Other**: Python-dotenv, PyYAML

## 📁 Project Structure

```
flight-delay-predictor/
├── data/
│   ├── raw/                    # Raw data from APIs
│   ├── processed/              # Cleaned and processed data
│   └── models/                 # Trained models
├── src/
│   ├── data_collection/        # Data collection modules
│   │   ├── flight_collector.py
│   │   └── weather_collector.py
│   ├── preprocessing/          # Data preprocessing
│   │   └── feature_engineering.py
│   ├── models/                 # ML models
│   │   ├── train_model.py
│   │   └── predict.py
│   └── visualization/          # Dashboards and plots
│       └── dashboard.py
├── notebooks/                  # Jupyter notebooks for EDA
├── config/                     # Configuration files
├── logs/                       # Log files
├── requirements.txt            # Dependencies
└── README.md                   # This file
```

## 🚀 Getting Started

### 1. Clone and Setup

```bash
cd flight-delay-predictor
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configuration (Optional)

Copy `.env.example` to `.env` and add your API keys (optional):

```bash
cp .env.example .env
```

For OpenWeatherMap (optional):
- Sign up at https://openweathermap.org/api
- Get your free API key
- Add to `.env` file

### 3. Collect Real-Time Data

```bash
# Start data collection
python src/data_collection/flight_collector.py
```

### 4. Train Models

```bash
# Train ML models
python src/models/train_model.py
```

### 5. Run Dashboard

```bash
# Launch interactive dashboard
streamlit run src/visualization/dashboard.py
```

## 📈 Model Performance

The system uses ensemble methods combining:
- **Random Forest Classifier**
- **XGBoost**
- **LightGBM**

Expected metrics:
- Accuracy: ~85-90%
- F1-Score: ~0.80-0.85
- Real-time prediction latency: <100ms

## 🎓 Learning Outcomes

This project demonstrates:
1. ✅ Real-time data collection from streaming APIs
2. ✅ Feature engineering for time-series data
3. ✅ Handling imbalanced datasets
4. ✅ Model training and evaluation
5. ✅ Real-time prediction system
6. ✅ Interactive dashboard development
7. ✅ End-to-end ML pipeline implementation

## 📝 Usage Examples

### Collect Flight Data
```python
from src.data_collection.flight_collector import FlightCollector

collector = FlightCollector()
collector.start_streaming(region='usa_east')
```

### Make Predictions
```python
from src.models.predict import DelayPredictor

predictor = DelayPredictor()
prediction = predictor.predict_delay(flight_data)
```

## 🐛 Troubleshooting

**Issue**: OpenSky API rate limit
**Solution**: Add optional credentials or increase polling interval

**Issue**: No weather data
**Solution**: System works without weather API, using historical averages

## 📚 References

- OpenSky Network: https://opensky-network.org/
- OpenWeatherMap: https://openweathermap.org/
- Aviation Weather: https://www.aviationweather.gov/

## 👨‍💻 Author

Data Science Capstone Project
Institute: [Your Institute Name]

## 📄 License

MIT License - Free for educational purposes
